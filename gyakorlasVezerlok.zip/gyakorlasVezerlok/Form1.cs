﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gyakorlasVezerlok
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void mutasdBTn_Click(object sender, EventArgs e)
        {
            kepPb.ImageLocation = utvonalTxt.Text;
        }

        private void magassagVSb_Scroll(object sender, ScrollEventArgs e)
        {
            kepPb.Height = magassagVSb.Value;
        }

        private void szelessegHSb_Scroll(object sender, ScrollEventArgs e)
        {
            kepPb.Width = szelessegHSb.Value;
        }
    }
}
