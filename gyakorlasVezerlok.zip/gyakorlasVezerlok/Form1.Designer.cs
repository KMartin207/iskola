﻿namespace gyakorlasVezerlok
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.kepTPg = new System.Windows.Forms.TabPage();
            this.magassagVSb = new System.Windows.Forms.HScrollBar();
            this.kepPb = new System.Windows.Forms.PictureBox();
            this.szelessegHSb = new System.Windows.Forms.HScrollBar();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.utvonalTxt = new System.Windows.Forms.TextBox();
            this.mutasdBTn = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.kepTPg.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kepPb)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.kepTPg);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(776, 426);
            this.tabControl1.TabIndex = 0;
            // 
            // kepTPg
            // 
            this.kepTPg.Controls.Add(this.mutasdBTn);
            this.kepTPg.Controls.Add(this.utvonalTxt);
            this.kepTPg.Controls.Add(this.magassagVSb);
            this.kepTPg.Controls.Add(this.kepPb);
            this.kepTPg.Controls.Add(this.szelessegHSb);
            this.kepTPg.Location = new System.Drawing.Point(4, 22);
            this.kepTPg.Name = "kepTPg";
            this.kepTPg.Padding = new System.Windows.Forms.Padding(3);
            this.kepTPg.Size = new System.Drawing.Size(768, 400);
            this.kepTPg.TabIndex = 0;
            this.kepTPg.Text = "Kép nagyítás";
            this.kepTPg.UseVisualStyleBackColor = true;
            // 
            // magassagVSb
            // 
            this.magassagVSb.Location = new System.Drawing.Point(21, 380);
            this.magassagVSb.Maximum = 300;
            this.magassagVSb.Name = "magassagVSb";
            this.magassagVSb.Size = new System.Drawing.Size(144, 17);
            this.magassagVSb.TabIndex = 2;
            this.magassagVSb.Scroll += new System.Windows.Forms.ScrollEventHandler(this.magassagVSb_Scroll);
            // 
            // kepPb
            // 
            this.kepPb.Location = new System.Drawing.Point(117, 65);
            this.kepPb.Name = "kepPb";
            this.kepPb.Size = new System.Drawing.Size(495, 280);
            this.kepPb.TabIndex = 1;
            this.kepPb.TabStop = false;
            // 
            // szelessegHSb
            // 
            this.szelessegHSb.Location = new System.Drawing.Point(388, 380);
            this.szelessegHSb.Maximum = 500;
            this.szelessegHSb.Name = "szelessegHSb";
            this.szelessegHSb.Size = new System.Drawing.Size(224, 17);
            this.szelessegHSb.TabIndex = 0;
            this.szelessegHSb.Scroll += new System.Windows.Forms.ScrollEventHandler(this.szelessegHSb_Scroll);
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(768, 400);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // utvonalTxt
            // 
            this.utvonalTxt.Location = new System.Drawing.Point(79, 39);
            this.utvonalTxt.Name = "utvonalTxt";
            this.utvonalTxt.Size = new System.Drawing.Size(407, 20);
            this.utvonalTxt.TabIndex = 3;
            // 
            // mutasdBTn
            // 
            this.mutasdBTn.Location = new System.Drawing.Point(619, 35);
            this.mutasdBTn.Name = "mutasdBTn";
            this.mutasdBTn.Size = new System.Drawing.Size(75, 23);
            this.mutasdBTn.TabIndex = 4;
            this.mutasdBTn.Text = "Mutasd";
            this.mutasdBTn.UseVisualStyleBackColor = true;
            this.mutasdBTn.Click += new System.EventHandler(this.mutasdBTn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.kepTPg.ResumeLayout(false);
            this.kepTPg.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kepPb)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage kepTPg;
        private System.Windows.Forms.HScrollBar magassagVSb;
        private System.Windows.Forms.PictureBox kepPb;
        private System.Windows.Forms.HScrollBar szelessegHSb;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button mutasdBTn;
        private System.Windows.Forms.TextBox utvonalTxt;
    }
}

