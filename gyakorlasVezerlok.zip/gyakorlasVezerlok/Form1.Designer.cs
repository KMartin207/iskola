﻿namespace gyakorlasVezerlok
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.kepTPg = new System.Windows.Forms.TabPage();
            this.mutasdBTn = new System.Windows.Forms.Button();
            this.utvonalTxt = new System.Windows.Forms.TextBox();
            this.magassagVSb = new System.Windows.Forms.HScrollBar();
            this.kepPb = new System.Windows.Forms.PictureBox();
            this.szelessegHSb = new System.Windows.Forms.HScrollBar();
            this.kepMozgasTPg = new System.Windows.Forms.TabPage();
            this.mozgoPb = new System.Windows.Forms.PictureBox();
            this.sudokuTPg = new System.Windows.Forms.TabPage();
            this.ellenorzesBTn = new System.Windows.Forms.Button();
            this.hozzaadBTn = new System.Windows.Forms.Button();
            this.kivonBTn = new System.Windows.Forms.Button();
            this.meretTxt = new System.Windows.Forms.TextBox();
            this.kezdoallapotTxt = new System.Windows.Forms.TextBox();
            this.hosszTxt = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.listTPg = new System.Windows.Forms.TabPage();
            this.termekTorolBtn = new System.Windows.Forms.Button();
            this.listaTorolBtn = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.termekTxt = new System.Windows.Forms.TextBox();
            this.ujElemBtn = new System.Windows.Forms.Button();
            this.listaLB = new System.Windows.Forms.ListBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.bevasarloListaCB = new System.Windows.Forms.ComboBox();
            this.comboBevasarloTxt = new System.Windows.Forms.TextBox();
            this.ComboHozzaAdBtn = new System.Windows.Forms.Button();
            this.DiavetitesTpg = new System.Windows.Forms.TabPage();
            this.balraNyilBtn = new System.Windows.Forms.Button();
            this.jobbraNyilBtn = new System.Windows.Forms.Button();
            this.kepekPb = new System.Windows.Forms.PictureBox();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.megjelenitesTpg = new System.Windows.Forms.TabPage();
            this.beallitasokTpg = new System.Windows.Forms.TabPage();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.linkHozzaadTxt = new System.Windows.Forms.TextBox();
            this.linkHozzaadBtn = new System.Windows.Forms.Button();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.tabControl1.SuspendLayout();
            this.kepTPg.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kepPb)).BeginInit();
            this.kepMozgasTPg.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mozgoPb)).BeginInit();
            this.sudokuTPg.SuspendLayout();
            this.listTPg.SuspendLayout();
            this.DiavetitesTpg.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kepekPb)).BeginInit();
            this.tabControl2.SuspendLayout();
            this.megjelenitesTpg.SuspendLayout();
            this.beallitasokTpg.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.kepTPg);
            this.tabControl1.Controls.Add(this.kepMozgasTPg);
            this.tabControl1.Controls.Add(this.sudokuTPg);
            this.tabControl1.Controls.Add(this.listTPg);
            this.tabControl1.Controls.Add(this.DiavetitesTpg);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(776, 426);
            this.tabControl1.TabIndex = 0;
            // 
            // kepTPg
            // 
            this.kepTPg.Controls.Add(this.mutasdBTn);
            this.kepTPg.Controls.Add(this.utvonalTxt);
            this.kepTPg.Controls.Add(this.magassagVSb);
            this.kepTPg.Controls.Add(this.kepPb);
            this.kepTPg.Controls.Add(this.szelessegHSb);
            this.kepTPg.Location = new System.Drawing.Point(4, 22);
            this.kepTPg.Name = "kepTPg";
            this.kepTPg.Padding = new System.Windows.Forms.Padding(3);
            this.kepTPg.Size = new System.Drawing.Size(768, 400);
            this.kepTPg.TabIndex = 0;
            this.kepTPg.Text = "Kép nagyítás";
            this.kepTPg.UseVisualStyleBackColor = true;
            // 
            // mutasdBTn
            // 
            this.mutasdBTn.Location = new System.Drawing.Point(619, 35);
            this.mutasdBTn.Name = "mutasdBTn";
            this.mutasdBTn.Size = new System.Drawing.Size(75, 23);
            this.mutasdBTn.TabIndex = 4;
            this.mutasdBTn.Text = "Mutasd";
            this.mutasdBTn.UseVisualStyleBackColor = true;
            this.mutasdBTn.Click += new System.EventHandler(this.mutasdBTn_Click);
            // 
            // utvonalTxt
            // 
            this.utvonalTxt.Location = new System.Drawing.Point(79, 39);
            this.utvonalTxt.Name = "utvonalTxt";
            this.utvonalTxt.Size = new System.Drawing.Size(407, 20);
            this.utvonalTxt.TabIndex = 3;
            this.utvonalTxt.TextChanged += new System.EventHandler(this.utvonalTxt_TextChanged);
            // 
            // magassagVSb
            // 
            this.magassagVSb.Location = new System.Drawing.Point(21, 380);
            this.magassagVSb.Maximum = 300;
            this.magassagVSb.Name = "magassagVSb";
            this.magassagVSb.Size = new System.Drawing.Size(144, 17);
            this.magassagVSb.TabIndex = 2;
            this.magassagVSb.Scroll += new System.Windows.Forms.ScrollEventHandler(this.magassagVSb_Scroll);
            // 
            // kepPb
            // 
            this.kepPb.Location = new System.Drawing.Point(117, 65);
            this.kepPb.Name = "kepPb";
            this.kepPb.Size = new System.Drawing.Size(495, 280);
            this.kepPb.TabIndex = 1;
            this.kepPb.TabStop = false;
            // 
            // szelessegHSb
            // 
            this.szelessegHSb.Location = new System.Drawing.Point(388, 380);
            this.szelessegHSb.Maximum = 500;
            this.szelessegHSb.Name = "szelessegHSb";
            this.szelessegHSb.Size = new System.Drawing.Size(224, 17);
            this.szelessegHSb.TabIndex = 0;
            this.szelessegHSb.Scroll += new System.Windows.Forms.ScrollEventHandler(this.szelessegHSb_Scroll);
            // 
            // kepMozgasTPg
            // 
            this.kepMozgasTPg.Controls.Add(this.mozgoPb);
            this.kepMozgasTPg.Location = new System.Drawing.Point(4, 22);
            this.kepMozgasTPg.Name = "kepMozgasTPg";
            this.kepMozgasTPg.Padding = new System.Windows.Forms.Padding(3);
            this.kepMozgasTPg.Size = new System.Drawing.Size(768, 400);
            this.kepMozgasTPg.TabIndex = 1;
            this.kepMozgasTPg.Text = "Kép mozgás";
            this.kepMozgasTPg.UseVisualStyleBackColor = true;
            // 
            // mozgoPb
            // 
            this.mozgoPb.ImageLocation = "https://images.paramount.tech/path/mgid:file:gsp:entertainment-assets:/sps/shared" +
    "/characters/kids/butters-stotch.png";
            this.mozgoPb.Location = new System.Drawing.Point(271, 122);
            this.mozgoPb.Name = "mozgoPb";
            this.mozgoPb.Size = new System.Drawing.Size(117, 92);
            this.mozgoPb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.mozgoPb.TabIndex = 0;
            this.mozgoPb.TabStop = false;
            // 
            // sudokuTPg
            // 
            this.sudokuTPg.Controls.Add(this.ellenorzesBTn);
            this.sudokuTPg.Controls.Add(this.hozzaadBTn);
            this.sudokuTPg.Controls.Add(this.kivonBTn);
            this.sudokuTPg.Controls.Add(this.meretTxt);
            this.sudokuTPg.Controls.Add(this.kezdoallapotTxt);
            this.sudokuTPg.Controls.Add(this.hosszTxt);
            this.sudokuTPg.Controls.Add(this.label3);
            this.sudokuTPg.Controls.Add(this.label2);
            this.sudokuTPg.Controls.Add(this.label1);
            this.sudokuTPg.Location = new System.Drawing.Point(4, 22);
            this.sudokuTPg.Name = "sudokuTPg";
            this.sudokuTPg.Size = new System.Drawing.Size(768, 400);
            this.sudokuTPg.TabIndex = 2;
            this.sudokuTPg.Text = "SudokuGUI";
            this.sudokuTPg.UseVisualStyleBackColor = true;
            // 
            // ellenorzesBTn
            // 
            this.ellenorzesBTn.Location = new System.Drawing.Point(509, 305);
            this.ellenorzesBTn.Name = "ellenorzesBTn";
            this.ellenorzesBTn.Size = new System.Drawing.Size(75, 23);
            this.ellenorzesBTn.TabIndex = 9;
            this.ellenorzesBTn.Text = "Ellenőrzés";
            this.ellenorzesBTn.UseVisualStyleBackColor = true;
            this.ellenorzesBTn.Click += new System.EventHandler(this.ellenorzesBTn_Click);
            // 
            // hozzaadBTn
            // 
            this.hozzaadBTn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.hozzaadBTn.Location = new System.Drawing.Point(373, 104);
            this.hozzaadBTn.Name = "hozzaadBTn";
            this.hozzaadBTn.Size = new System.Drawing.Size(26, 26);
            this.hozzaadBTn.TabIndex = 8;
            this.hozzaadBTn.Text = "+";
            this.hozzaadBTn.UseVisualStyleBackColor = true;
            this.hozzaadBTn.Click += new System.EventHandler(this.hozzaadBTn_Click);
            // 
            // kivonBTn
            // 
            this.kivonBTn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.kivonBTn.Location = new System.Drawing.Point(284, 104);
            this.kivonBTn.Name = "kivonBTn";
            this.kivonBTn.Size = new System.Drawing.Size(26, 26);
            this.kivonBTn.TabIndex = 7;
            this.kivonBTn.Text = "-";
            this.kivonBTn.UseVisualStyleBackColor = true;
            this.kivonBTn.Click += new System.EventHandler(this.kivonBTn_Click);
            // 
            // meretTxt
            // 
            this.meretTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.meretTxt.Location = new System.Drawing.Point(330, 104);
            this.meretTxt.Name = "meretTxt";
            this.meretTxt.Size = new System.Drawing.Size(22, 26);
            this.meretTxt.TabIndex = 6;
            this.meretTxt.Text = "4";
            this.meretTxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.meretTxt.TextChanged += new System.EventHandler(this.meretTxt_TextChanged);
            // 
            // kezdoallapotTxt
            // 
            this.kezdoallapotTxt.Location = new System.Drawing.Point(90, 248);
            this.kezdoallapotTxt.Name = "kezdoallapotTxt";
            this.kezdoallapotTxt.Size = new System.Drawing.Size(453, 20);
            this.kezdoallapotTxt.TabIndex = 4;
            this.kezdoallapotTxt.TextChanged += new System.EventHandler(this.kezdoallapotTxt_TextChanged);
            // 
            // hosszTxt
            // 
            this.hosszTxt.AutoSize = true;
            this.hosszTxt.Location = new System.Drawing.Point(145, 305);
            this.hosszTxt.Name = "hosszTxt";
            this.hosszTxt.Size = new System.Drawing.Size(13, 13);
            this.hosszTxt.TabIndex = 3;
            this.hosszTxt.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(102, 304);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Hossz:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(87, 217);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Kezdőállapot:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(87, 104);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Új feladvány mérete:";
            // 
            // listTPg
            // 
            this.listTPg.Controls.Add(this.ComboHozzaAdBtn);
            this.listTPg.Controls.Add(this.comboBevasarloTxt);
            this.listTPg.Controls.Add(this.bevasarloListaCB);
            this.listTPg.Controls.Add(this.termekTorolBtn);
            this.listTPg.Controls.Add(this.listaTorolBtn);
            this.listTPg.Controls.Add(this.label4);
            this.listTPg.Controls.Add(this.termekTxt);
            this.listTPg.Controls.Add(this.ujElemBtn);
            this.listTPg.Controls.Add(this.listaLB);
            this.listTPg.Location = new System.Drawing.Point(4, 22);
            this.listTPg.Name = "listTPg";
            this.listTPg.Size = new System.Drawing.Size(768, 400);
            this.listTPg.TabIndex = 3;
            this.listTPg.Text = "Lista";
            this.listTPg.UseVisualStyleBackColor = true;
            // 
            // termekTorolBtn
            // 
            this.termekTorolBtn.Location = new System.Drawing.Point(199, 340);
            this.termekTorolBtn.Name = "termekTorolBtn";
            this.termekTorolBtn.Size = new System.Drawing.Size(136, 23);
            this.termekTorolBtn.TabIndex = 5;
            this.termekTorolBtn.Text = "Termék törlése";
            this.termekTorolBtn.UseVisualStyleBackColor = true;
            this.termekTorolBtn.Click += new System.EventHandler(this.termekTorolBtn_Click);
            // 
            // listaTorolBtn
            // 
            this.listaTorolBtn.BackColor = System.Drawing.Color.Red;
            this.listaTorolBtn.ForeColor = System.Drawing.SystemColors.ControlText;
            this.listaTorolBtn.Location = new System.Drawing.Point(65, 332);
            this.listaTorolBtn.Name = "listaTorolBtn";
            this.listaTorolBtn.Size = new System.Drawing.Size(101, 38);
            this.listaTorolBtn.TabIndex = 4;
            this.listaTorolBtn.Text = "Lista törlése";
            this.listaTorolBtn.UseVisualStyleBackColor = false;
            this.listaTorolBtn.Click += new System.EventHandler(this.listaTorolBtn_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(62, 40);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Bevásárlólista";
            // 
            // termekTxt
            // 
            this.termekTxt.Location = new System.Drawing.Point(65, 257);
            this.termekTxt.Name = "termekTxt";
            this.termekTxt.Size = new System.Drawing.Size(175, 20);
            this.termekTxt.TabIndex = 2;
            this.termekTxt.TextChanged += new System.EventHandler(this.termekTxt_TextChanged);
            // 
            // ujElemBtn
            // 
            this.ujElemBtn.Location = new System.Drawing.Point(260, 257);
            this.ujElemBtn.Name = "ujElemBtn";
            this.ujElemBtn.Size = new System.Drawing.Size(75, 23);
            this.ujElemBtn.TabIndex = 1;
            this.ujElemBtn.Text = "Új elem";
            this.ujElemBtn.UseVisualStyleBackColor = true;
            this.ujElemBtn.Click += new System.EventHandler(this.ujElemBtn_Click);
            // 
            // listaLB
            // 
            this.listaLB.FormattingEnabled = true;
            this.listaLB.Location = new System.Drawing.Point(65, 71);
            this.listaLB.Name = "listaLB";
            this.listaLB.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.listaLB.Size = new System.Drawing.Size(160, 147);
            this.listaLB.TabIndex = 0;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 10;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // bevasarloListaCB
            // 
            this.bevasarloListaCB.AutoCompleteCustomSource.AddRange(new string[] {
            "xcy",
            "",
            "fghfhf"});
            this.bevasarloListaCB.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.bevasarloListaCB.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.bevasarloListaCB.FormattingEnabled = true;
            this.bevasarloListaCB.Location = new System.Drawing.Point(488, 121);
            this.bevasarloListaCB.Name = "bevasarloListaCB";
            this.bevasarloListaCB.Size = new System.Drawing.Size(121, 21);
            this.bevasarloListaCB.TabIndex = 6;
            // 
            // comboBevasarloTxt
            // 
            this.comboBevasarloTxt.Location = new System.Drawing.Point(460, 260);
            this.comboBevasarloTxt.Name = "comboBevasarloTxt";
            this.comboBevasarloTxt.Size = new System.Drawing.Size(130, 20);
            this.comboBevasarloTxt.TabIndex = 7;
            // 
            // ComboHozzaAdBtn
            // 
            this.ComboHozzaAdBtn.Location = new System.Drawing.Point(625, 258);
            this.ComboHozzaAdBtn.Name = "ComboHozzaAdBtn";
            this.ComboHozzaAdBtn.Size = new System.Drawing.Size(75, 23);
            this.ComboHozzaAdBtn.TabIndex = 8;
            this.ComboHozzaAdBtn.Text = "Hozzáadás";
            this.ComboHozzaAdBtn.UseVisualStyleBackColor = true;
            this.ComboHozzaAdBtn.Click += new System.EventHandler(this.ComboHozzaAdBtn_Click);
            // 
            // DiavetitesTpg
            // 
            this.DiavetitesTpg.Controls.Add(this.tabControl2);
            this.DiavetitesTpg.Location = new System.Drawing.Point(4, 22);
            this.DiavetitesTpg.Name = "DiavetitesTpg";
            this.DiavetitesTpg.Size = new System.Drawing.Size(768, 400);
            this.DiavetitesTpg.TabIndex = 4;
            this.DiavetitesTpg.Text = "Diavetítés";
            this.DiavetitesTpg.UseVisualStyleBackColor = true;
            // 
            // balraNyilBtn
            // 
            this.balraNyilBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.balraNyilBtn.Location = new System.Drawing.Point(63, 152);
            this.balraNyilBtn.Name = "balraNyilBtn";
            this.balraNyilBtn.Size = new System.Drawing.Size(38, 54);
            this.balraNyilBtn.TabIndex = 0;
            this.balraNyilBtn.Text = "<";
            this.balraNyilBtn.UseVisualStyleBackColor = true;
            // 
            // jobbraNyilBtn
            // 
            this.jobbraNyilBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.jobbraNyilBtn.Location = new System.Drawing.Point(630, 152);
            this.jobbraNyilBtn.Name = "jobbraNyilBtn";
            this.jobbraNyilBtn.Size = new System.Drawing.Size(36, 54);
            this.jobbraNyilBtn.TabIndex = 1;
            this.jobbraNyilBtn.Text = ">";
            this.jobbraNyilBtn.UseVisualStyleBackColor = true;
            this.jobbraNyilBtn.Click += new System.EventHandler(this.jobbraNyilBtn_Click);
            // 
            // kepekPb
            // 
            this.kepekPb.Location = new System.Drawing.Point(180, 20);
            this.kepekPb.Name = "kepekPb";
            this.kepekPb.Size = new System.Drawing.Size(381, 305);
            this.kepekPb.TabIndex = 2;
            this.kepekPb.TabStop = false;
            this.kepekPb.Click += new System.EventHandler(this.kepekPb_Click);
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.megjelenitesTpg);
            this.tabControl2.Controls.Add(this.beallitasokTpg);
            this.tabControl2.Location = new System.Drawing.Point(3, 3);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(762, 394);
            this.tabControl2.TabIndex = 4;
            // 
            // megjelenitesTpg
            // 
            this.megjelenitesTpg.Controls.Add(this.kepekPb);
            this.megjelenitesTpg.Controls.Add(this.jobbraNyilBtn);
            this.megjelenitesTpg.Controls.Add(this.balraNyilBtn);
            this.megjelenitesTpg.Location = new System.Drawing.Point(4, 22);
            this.megjelenitesTpg.Name = "megjelenitesTpg";
            this.megjelenitesTpg.Padding = new System.Windows.Forms.Padding(3);
            this.megjelenitesTpg.Size = new System.Drawing.Size(754, 368);
            this.megjelenitesTpg.TabIndex = 0;
            this.megjelenitesTpg.Text = "Megjelenítés";
            this.megjelenitesTpg.UseVisualStyleBackColor = true;
            // 
            // beallitasokTpg
            // 
            this.beallitasokTpg.Controls.Add(this.linkHozzaadBtn);
            this.beallitasokTpg.Controls.Add(this.linkHozzaadTxt);
            this.beallitasokTpg.Controls.Add(this.label6);
            this.beallitasokTpg.Controls.Add(this.label5);
            this.beallitasokTpg.Controls.Add(this.checkBox1);
            this.beallitasokTpg.Location = new System.Drawing.Point(4, 22);
            this.beallitasokTpg.Name = "beallitasokTpg";
            this.beallitasokTpg.Padding = new System.Windows.Forms.Padding(3);
            this.beallitasokTpg.Size = new System.Drawing.Size(754, 368);
            this.beallitasokTpg.TabIndex = 1;
            this.beallitasokTpg.Text = "Beállítások";
            this.beallitasokTpg.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(309, 134);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(84, 17);
            this.checkBox1.TabIndex = 4;
            this.checkBox1.Text = "Autómatikus";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label5.Location = new System.Drawing.Point(284, 27);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(146, 31);
            this.label5.TabIndex = 5;
            this.label5.Text = "Beállítások";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.label6.Location = new System.Drawing.Point(286, 234);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(161, 22);
            this.label6.TabIndex = 6;
            this.label6.Text = "Új kép hozzáadása";
            // 
            // linkHozzaadTxt
            // 
            this.linkHozzaadTxt.Location = new System.Drawing.Point(178, 270);
            this.linkHozzaadTxt.Name = "linkHozzaadTxt";
            this.linkHozzaadTxt.Size = new System.Drawing.Size(369, 20);
            this.linkHozzaadTxt.TabIndex = 7;
            // 
            // linkHozzaadBtn
            // 
            this.linkHozzaadBtn.Location = new System.Drawing.Point(318, 314);
            this.linkHozzaadBtn.Name = "linkHozzaadBtn";
            this.linkHozzaadBtn.Size = new System.Drawing.Size(75, 23);
            this.linkHozzaadBtn.TabIndex = 8;
            this.linkHozzaadBtn.Text = "Hozzáadás";
            this.linkHozzaadBtn.UseVisualStyleBackColor = true;
            // 
            // timer2
            // 
            this.timer2.Enabled = true;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.kepTPg.ResumeLayout(false);
            this.kepTPg.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kepPb)).EndInit();
            this.kepMozgasTPg.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.mozgoPb)).EndInit();
            this.sudokuTPg.ResumeLayout(false);
            this.sudokuTPg.PerformLayout();
            this.listTPg.ResumeLayout(false);
            this.listTPg.PerformLayout();
            this.DiavetitesTpg.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.kepekPb)).EndInit();
            this.tabControl2.ResumeLayout(false);
            this.megjelenitesTpg.ResumeLayout(false);
            this.beallitasokTpg.ResumeLayout(false);
            this.beallitasokTpg.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage kepTPg;
        private System.Windows.Forms.HScrollBar magassagVSb;
        private System.Windows.Forms.PictureBox kepPb;
        private System.Windows.Forms.HScrollBar szelessegHSb;
        private System.Windows.Forms.TabPage kepMozgasTPg;
        private System.Windows.Forms.Button mutasdBTn;
        private System.Windows.Forms.TextBox utvonalTxt;
        private System.Windows.Forms.PictureBox mozgoPb;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TabPage sudokuTPg;
        private System.Windows.Forms.Button hozzaadBTn;
        private System.Windows.Forms.Button kivonBTn;
        private System.Windows.Forms.TextBox meretTxt;
        private System.Windows.Forms.TextBox kezdoallapotTxt;
        private System.Windows.Forms.Label hosszTxt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button ellenorzesBTn;
        private System.Windows.Forms.TabPage listTPg;
        private System.Windows.Forms.ListBox listaLB;
        private System.Windows.Forms.Button ujElemBtn;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox termekTxt;
        private System.Windows.Forms.Button listaTorolBtn;
        private System.Windows.Forms.Button termekTorolBtn;
        private System.Windows.Forms.ComboBox bevasarloListaCB;
        private System.Windows.Forms.Button ComboHozzaAdBtn;
        private System.Windows.Forms.TextBox comboBevasarloTxt;
        private System.Windows.Forms.TabPage DiavetitesTpg;
        private System.Windows.Forms.PictureBox kepekPb;
        private System.Windows.Forms.Button jobbraNyilBtn;
        private System.Windows.Forms.Button balraNyilBtn;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage megjelenitesTpg;
        private System.Windows.Forms.TabPage beallitasokTpg;
        private System.Windows.Forms.Button linkHozzaadBtn;
        private System.Windows.Forms.TextBox linkHozzaadTxt;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Timer timer2;
    }
}

