﻿namespace gyakorlasVezerlok
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.kepTPg = new System.Windows.Forms.TabPage();
            this.mutasdBTn = new System.Windows.Forms.Button();
            this.utvonalTxt = new System.Windows.Forms.TextBox();
            this.magassagVSb = new System.Windows.Forms.HScrollBar();
            this.kepPb = new System.Windows.Forms.PictureBox();
            this.szelessegHSb = new System.Windows.Forms.HScrollBar();
            this.kepMozgasTPg = new System.Windows.Forms.TabPage();
            this.mozgoPb = new System.Windows.Forms.PictureBox();
            this.sudokuTPg = new System.Windows.Forms.TabPage();
            this.ellenorzesBTn = new System.Windows.Forms.Button();
            this.hozzaadBTn = new System.Windows.Forms.Button();
            this.kivonBTn = new System.Windows.Forms.Button();
            this.meretTxt = new System.Windows.Forms.TextBox();
            this.kezdoallapotTxt = new System.Windows.Forms.TextBox();
            this.hosszTxt = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.listTPg = new System.Windows.Forms.TabPage();
            this.ComboHozzaAdBtn = new System.Windows.Forms.Button();
            this.comboBevasarloTxt = new System.Windows.Forms.TextBox();
            this.bevasarloListaCB = new System.Windows.Forms.ComboBox();
            this.termekTorolBtn = new System.Windows.Forms.Button();
            this.listaTorolBtn = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.termekTxt = new System.Windows.Forms.TextBox();
            this.ujElemBtn = new System.Windows.Forms.Button();
            this.listaLB = new System.Windows.Forms.ListBox();
            this.DiavetitesTpg = new System.Windows.Forms.TabPage();
            this.label7 = new System.Windows.Forms.Label();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.megjelenitesTpg = new System.Windows.Forms.TabPage();
            this.sorszamTxt = new System.Windows.Forms.Label();
            this.kepekPb = new System.Windows.Forms.PictureBox();
            this.jobbraNyilBtn = new System.Windows.Forms.Button();
            this.balraNyilBtn = new System.Windows.Forms.Button();
            this.beallitasokTpg = new System.Windows.Forms.TabPage();
            this.sebessegTxt = new System.Windows.Forms.Label();
            this.gyorsRb = new System.Windows.Forms.RadioButton();
            this.kozepesRb = new System.Windows.Forms.RadioButton();
            this.lassuRb = new System.Windows.Forms.RadioButton();
            this.linkHozzaadBtn = new System.Windows.Forms.Button();
            this.linkHozzaadTxt = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.automatikusVetitesCB = new System.Windows.Forms.CheckBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.felismeroTpg = new System.Windows.Forms.TabPage();
            this.label8 = new System.Windows.Forms.Label();
            this.label = new System.Windows.Forms.Label();
            this.orszagLbl = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.varosCB = new System.Windows.Forms.ComboBox();
            this.ellenorizBtn = new System.Windows.Forms.Button();
            this.pontBolLbl = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.pontLbl = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.kepTPg.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kepPb)).BeginInit();
            this.kepMozgasTPg.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mozgoPb)).BeginInit();
            this.sudokuTPg.SuspendLayout();
            this.listTPg.SuspendLayout();
            this.DiavetitesTpg.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.megjelenitesTpg.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kepekPb)).BeginInit();
            this.beallitasokTpg.SuspendLayout();
            this.felismeroTpg.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.kepTPg);
            this.tabControl1.Controls.Add(this.kepMozgasTPg);
            this.tabControl1.Controls.Add(this.sudokuTPg);
            this.tabControl1.Controls.Add(this.listTPg);
            this.tabControl1.Controls.Add(this.DiavetitesTpg);
            this.tabControl1.Controls.Add(this.felismeroTpg);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(776, 426);
            this.tabControl1.TabIndex = 0;
            // 
            // kepTPg
            // 
            this.kepTPg.Controls.Add(this.mutasdBTn);
            this.kepTPg.Controls.Add(this.utvonalTxt);
            this.kepTPg.Controls.Add(this.magassagVSb);
            this.kepTPg.Controls.Add(this.kepPb);
            this.kepTPg.Controls.Add(this.szelessegHSb);
            this.kepTPg.Location = new System.Drawing.Point(4, 22);
            this.kepTPg.Name = "kepTPg";
            this.kepTPg.Padding = new System.Windows.Forms.Padding(3);
            this.kepTPg.Size = new System.Drawing.Size(768, 400);
            this.kepTPg.TabIndex = 0;
            this.kepTPg.Text = "Kép nagyítás";
            this.kepTPg.UseVisualStyleBackColor = true;
            // 
            // mutasdBTn
            // 
            this.mutasdBTn.Location = new System.Drawing.Point(619, 35);
            this.mutasdBTn.Name = "mutasdBTn";
            this.mutasdBTn.Size = new System.Drawing.Size(75, 23);
            this.mutasdBTn.TabIndex = 4;
            this.mutasdBTn.Text = "Mutasd";
            this.mutasdBTn.UseVisualStyleBackColor = true;
            this.mutasdBTn.Click += new System.EventHandler(this.mutasdBTn_Click);
            // 
            // utvonalTxt
            // 
            this.utvonalTxt.Location = new System.Drawing.Point(79, 39);
            this.utvonalTxt.Name = "utvonalTxt";
            this.utvonalTxt.Size = new System.Drawing.Size(407, 20);
            this.utvonalTxt.TabIndex = 3;
            this.utvonalTxt.TextChanged += new System.EventHandler(this.utvonalTxt_TextChanged);
            // 
            // magassagVSb
            // 
            this.magassagVSb.Location = new System.Drawing.Point(21, 380);
            this.magassagVSb.Maximum = 300;
            this.magassagVSb.Name = "magassagVSb";
            this.magassagVSb.Size = new System.Drawing.Size(144, 17);
            this.magassagVSb.TabIndex = 2;
            this.magassagVSb.Scroll += new System.Windows.Forms.ScrollEventHandler(this.magassagVSb_Scroll);
            // 
            // kepPb
            // 
            this.kepPb.Location = new System.Drawing.Point(117, 65);
            this.kepPb.Name = "kepPb";
            this.kepPb.Size = new System.Drawing.Size(495, 280);
            this.kepPb.TabIndex = 1;
            this.kepPb.TabStop = false;
            // 
            // szelessegHSb
            // 
            this.szelessegHSb.Location = new System.Drawing.Point(388, 380);
            this.szelessegHSb.Maximum = 500;
            this.szelessegHSb.Name = "szelessegHSb";
            this.szelessegHSb.Size = new System.Drawing.Size(224, 17);
            this.szelessegHSb.TabIndex = 0;
            this.szelessegHSb.Scroll += new System.Windows.Forms.ScrollEventHandler(this.szelessegHSb_Scroll);
            // 
            // kepMozgasTPg
            // 
            this.kepMozgasTPg.Controls.Add(this.mozgoPb);
            this.kepMozgasTPg.Location = new System.Drawing.Point(4, 22);
            this.kepMozgasTPg.Name = "kepMozgasTPg";
            this.kepMozgasTPg.Padding = new System.Windows.Forms.Padding(3);
            this.kepMozgasTPg.Size = new System.Drawing.Size(768, 400);
            this.kepMozgasTPg.TabIndex = 1;
            this.kepMozgasTPg.Text = "Kép mozgás";
            this.kepMozgasTPg.UseVisualStyleBackColor = true;
            // 
            // mozgoPb
            // 
            this.mozgoPb.ImageLocation = "https://images.paramount.tech/path/mgid:file:gsp:entertainment-assets:/sps/shared" +
    "/characters/kids/butters-stotch.png";
            this.mozgoPb.Location = new System.Drawing.Point(271, 122);
            this.mozgoPb.Name = "mozgoPb";
            this.mozgoPb.Size = new System.Drawing.Size(117, 92);
            this.mozgoPb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.mozgoPb.TabIndex = 0;
            this.mozgoPb.TabStop = false;
            // 
            // sudokuTPg
            // 
            this.sudokuTPg.Controls.Add(this.ellenorzesBTn);
            this.sudokuTPg.Controls.Add(this.hozzaadBTn);
            this.sudokuTPg.Controls.Add(this.kivonBTn);
            this.sudokuTPg.Controls.Add(this.meretTxt);
            this.sudokuTPg.Controls.Add(this.kezdoallapotTxt);
            this.sudokuTPg.Controls.Add(this.hosszTxt);
            this.sudokuTPg.Controls.Add(this.label3);
            this.sudokuTPg.Controls.Add(this.label2);
            this.sudokuTPg.Controls.Add(this.label1);
            this.sudokuTPg.Location = new System.Drawing.Point(4, 22);
            this.sudokuTPg.Name = "sudokuTPg";
            this.sudokuTPg.Size = new System.Drawing.Size(768, 400);
            this.sudokuTPg.TabIndex = 2;
            this.sudokuTPg.Text = "SudokuGUI";
            this.sudokuTPg.UseVisualStyleBackColor = true;
            // 
            // ellenorzesBTn
            // 
            this.ellenorzesBTn.Location = new System.Drawing.Point(509, 305);
            this.ellenorzesBTn.Name = "ellenorzesBTn";
            this.ellenorzesBTn.Size = new System.Drawing.Size(75, 23);
            this.ellenorzesBTn.TabIndex = 9;
            this.ellenorzesBTn.Text = "Ellenőrzés";
            this.ellenorzesBTn.UseVisualStyleBackColor = true;
            this.ellenorzesBTn.Click += new System.EventHandler(this.ellenorzesBTn_Click);
            // 
            // hozzaadBTn
            // 
            this.hozzaadBTn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.hozzaadBTn.Location = new System.Drawing.Point(373, 104);
            this.hozzaadBTn.Name = "hozzaadBTn";
            this.hozzaadBTn.Size = new System.Drawing.Size(26, 26);
            this.hozzaadBTn.TabIndex = 8;
            this.hozzaadBTn.Text = "+";
            this.hozzaadBTn.UseVisualStyleBackColor = true;
            this.hozzaadBTn.Click += new System.EventHandler(this.hozzaadBTn_Click);
            // 
            // kivonBTn
            // 
            this.kivonBTn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.kivonBTn.Location = new System.Drawing.Point(284, 104);
            this.kivonBTn.Name = "kivonBTn";
            this.kivonBTn.Size = new System.Drawing.Size(26, 26);
            this.kivonBTn.TabIndex = 7;
            this.kivonBTn.Text = "-";
            this.kivonBTn.UseVisualStyleBackColor = true;
            this.kivonBTn.Click += new System.EventHandler(this.kivonBTn_Click);
            // 
            // meretTxt
            // 
            this.meretTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.meretTxt.Location = new System.Drawing.Point(330, 104);
            this.meretTxt.Name = "meretTxt";
            this.meretTxt.Size = new System.Drawing.Size(22, 26);
            this.meretTxt.TabIndex = 6;
            this.meretTxt.Text = "4";
            this.meretTxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.meretTxt.TextChanged += new System.EventHandler(this.meretTxt_TextChanged);
            // 
            // kezdoallapotTxt
            // 
            this.kezdoallapotTxt.Location = new System.Drawing.Point(90, 248);
            this.kezdoallapotTxt.Name = "kezdoallapotTxt";
            this.kezdoallapotTxt.Size = new System.Drawing.Size(453, 20);
            this.kezdoallapotTxt.TabIndex = 4;
            this.kezdoallapotTxt.TextChanged += new System.EventHandler(this.kezdoallapotTxt_TextChanged);
            // 
            // hosszTxt
            // 
            this.hosszTxt.AutoSize = true;
            this.hosszTxt.Location = new System.Drawing.Point(145, 305);
            this.hosszTxt.Name = "hosszTxt";
            this.hosszTxt.Size = new System.Drawing.Size(13, 13);
            this.hosszTxt.TabIndex = 3;
            this.hosszTxt.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(102, 304);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Hossz:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(87, 217);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Kezdőállapot:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(87, 104);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Új feladvány mérete:";
            // 
            // listTPg
            // 
            this.listTPg.Controls.Add(this.ComboHozzaAdBtn);
            this.listTPg.Controls.Add(this.comboBevasarloTxt);
            this.listTPg.Controls.Add(this.bevasarloListaCB);
            this.listTPg.Controls.Add(this.termekTorolBtn);
            this.listTPg.Controls.Add(this.listaTorolBtn);
            this.listTPg.Controls.Add(this.label4);
            this.listTPg.Controls.Add(this.termekTxt);
            this.listTPg.Controls.Add(this.ujElemBtn);
            this.listTPg.Controls.Add(this.listaLB);
            this.listTPg.Location = new System.Drawing.Point(4, 22);
            this.listTPg.Name = "listTPg";
            this.listTPg.Size = new System.Drawing.Size(768, 400);
            this.listTPg.TabIndex = 3;
            this.listTPg.Text = "Lista";
            this.listTPg.UseVisualStyleBackColor = true;
            // 
            // ComboHozzaAdBtn
            // 
            this.ComboHozzaAdBtn.Location = new System.Drawing.Point(625, 258);
            this.ComboHozzaAdBtn.Name = "ComboHozzaAdBtn";
            this.ComboHozzaAdBtn.Size = new System.Drawing.Size(75, 23);
            this.ComboHozzaAdBtn.TabIndex = 8;
            this.ComboHozzaAdBtn.Text = "Hozzáadás";
            this.ComboHozzaAdBtn.UseVisualStyleBackColor = true;
            this.ComboHozzaAdBtn.Click += new System.EventHandler(this.ComboHozzaAdBtn_Click);
            // 
            // comboBevasarloTxt
            // 
            this.comboBevasarloTxt.Location = new System.Drawing.Point(460, 260);
            this.comboBevasarloTxt.Name = "comboBevasarloTxt";
            this.comboBevasarloTxt.Size = new System.Drawing.Size(130, 20);
            this.comboBevasarloTxt.TabIndex = 7;
            // 
            // bevasarloListaCB
            // 
            this.bevasarloListaCB.AutoCompleteCustomSource.AddRange(new string[] {
            "xcy",
            "",
            "fghfhf"});
            this.bevasarloListaCB.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.bevasarloListaCB.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.bevasarloListaCB.FormattingEnabled = true;
            this.bevasarloListaCB.Location = new System.Drawing.Point(488, 121);
            this.bevasarloListaCB.Name = "bevasarloListaCB";
            this.bevasarloListaCB.Size = new System.Drawing.Size(121, 21);
            this.bevasarloListaCB.TabIndex = 6;
            // 
            // termekTorolBtn
            // 
            this.termekTorolBtn.Location = new System.Drawing.Point(199, 340);
            this.termekTorolBtn.Name = "termekTorolBtn";
            this.termekTorolBtn.Size = new System.Drawing.Size(136, 23);
            this.termekTorolBtn.TabIndex = 5;
            this.termekTorolBtn.Text = "Termék törlése";
            this.termekTorolBtn.UseVisualStyleBackColor = true;
            this.termekTorolBtn.Click += new System.EventHandler(this.termekTorolBtn_Click);
            // 
            // listaTorolBtn
            // 
            this.listaTorolBtn.BackColor = System.Drawing.Color.Red;
            this.listaTorolBtn.ForeColor = System.Drawing.SystemColors.ControlText;
            this.listaTorolBtn.Location = new System.Drawing.Point(65, 332);
            this.listaTorolBtn.Name = "listaTorolBtn";
            this.listaTorolBtn.Size = new System.Drawing.Size(101, 38);
            this.listaTorolBtn.TabIndex = 4;
            this.listaTorolBtn.Text = "Lista törlése";
            this.listaTorolBtn.UseVisualStyleBackColor = false;
            this.listaTorolBtn.Click += new System.EventHandler(this.listaTorolBtn_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(62, 40);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Bevásárlólista";
            // 
            // termekTxt
            // 
            this.termekTxt.Location = new System.Drawing.Point(65, 257);
            this.termekTxt.Name = "termekTxt";
            this.termekTxt.Size = new System.Drawing.Size(175, 20);
            this.termekTxt.TabIndex = 2;
            this.termekTxt.TextChanged += new System.EventHandler(this.termekTxt_TextChanged);
            // 
            // ujElemBtn
            // 
            this.ujElemBtn.Location = new System.Drawing.Point(260, 257);
            this.ujElemBtn.Name = "ujElemBtn";
            this.ujElemBtn.Size = new System.Drawing.Size(75, 23);
            this.ujElemBtn.TabIndex = 1;
            this.ujElemBtn.Text = "Új elem";
            this.ujElemBtn.UseVisualStyleBackColor = true;
            this.ujElemBtn.Click += new System.EventHandler(this.ujElemBtn_Click);
            // 
            // listaLB
            // 
            this.listaLB.FormattingEnabled = true;
            this.listaLB.Location = new System.Drawing.Point(65, 71);
            this.listaLB.Name = "listaLB";
            this.listaLB.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.listaLB.Size = new System.Drawing.Size(160, 147);
            this.listaLB.TabIndex = 0;
            // 
            // DiavetitesTpg
            // 
            this.DiavetitesTpg.Controls.Add(this.label7);
            this.DiavetitesTpg.Controls.Add(this.tabControl2);
            this.DiavetitesTpg.Location = new System.Drawing.Point(4, 22);
            this.DiavetitesTpg.Name = "DiavetitesTpg";
            this.DiavetitesTpg.Size = new System.Drawing.Size(768, 400);
            this.DiavetitesTpg.TabIndex = 4;
            this.DiavetitesTpg.Text = "Diavetítés";
            this.DiavetitesTpg.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(20, 20);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 13);
            this.label7.TabIndex = 5;
            this.label7.Text = "label7";
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.megjelenitesTpg);
            this.tabControl2.Controls.Add(this.beallitasokTpg);
            this.tabControl2.Location = new System.Drawing.Point(3, 3);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(762, 394);
            this.tabControl2.TabIndex = 4;
            // 
            // megjelenitesTpg
            // 
            this.megjelenitesTpg.Controls.Add(this.sorszamTxt);
            this.megjelenitesTpg.Controls.Add(this.kepekPb);
            this.megjelenitesTpg.Controls.Add(this.jobbraNyilBtn);
            this.megjelenitesTpg.Controls.Add(this.balraNyilBtn);
            this.megjelenitesTpg.Location = new System.Drawing.Point(4, 22);
            this.megjelenitesTpg.Name = "megjelenitesTpg";
            this.megjelenitesTpg.Padding = new System.Windows.Forms.Padding(3);
            this.megjelenitesTpg.Size = new System.Drawing.Size(754, 368);
            this.megjelenitesTpg.TabIndex = 0;
            this.megjelenitesTpg.Text = "Megjelenítés";
            this.megjelenitesTpg.UseVisualStyleBackColor = true;
            // 
            // sorszamTxt
            // 
            this.sorszamTxt.AutoSize = true;
            this.sorszamTxt.Location = new System.Drawing.Point(65, 52);
            this.sorszamTxt.Name = "sorszamTxt";
            this.sorszamTxt.Size = new System.Drawing.Size(47, 13);
            this.sorszamTxt.TabIndex = 3;
            this.sorszamTxt.Text = "Sorszam";
            this.sorszamTxt.Click += new System.EventHandler(this.sorszamTxt_Click);
            // 
            // kepekPb
            // 
            this.kepekPb.ImageLocation = "https://media.tenor.com/LdPYwrYLgeYAAAAM/guy-funny.gif";
            this.kepekPb.Location = new System.Drawing.Point(180, 20);
            this.kepekPb.Name = "kepekPb";
            this.kepekPb.Size = new System.Drawing.Size(381, 305);
            this.kepekPb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.kepekPb.TabIndex = 2;
            this.kepekPb.TabStop = false;
            this.kepekPb.Click += new System.EventHandler(this.kepekPb_Click);
            // 
            // jobbraNyilBtn
            // 
            this.jobbraNyilBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.jobbraNyilBtn.Location = new System.Drawing.Point(630, 152);
            this.jobbraNyilBtn.Name = "jobbraNyilBtn";
            this.jobbraNyilBtn.Size = new System.Drawing.Size(36, 54);
            this.jobbraNyilBtn.TabIndex = 1;
            this.jobbraNyilBtn.Text = ">";
            this.jobbraNyilBtn.UseVisualStyleBackColor = true;
            this.jobbraNyilBtn.Click += new System.EventHandler(this.jobbraNyilBtn_Click);
            // 
            // balraNyilBtn
            // 
            this.balraNyilBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.balraNyilBtn.Location = new System.Drawing.Point(63, 152);
            this.balraNyilBtn.Name = "balraNyilBtn";
            this.balraNyilBtn.Size = new System.Drawing.Size(38, 54);
            this.balraNyilBtn.TabIndex = 0;
            this.balraNyilBtn.Text = "<";
            this.balraNyilBtn.UseVisualStyleBackColor = true;
            this.balraNyilBtn.Click += new System.EventHandler(this.balraNyilBtn_Click);
            // 
            // beallitasokTpg
            // 
            this.beallitasokTpg.Controls.Add(this.sebessegTxt);
            this.beallitasokTpg.Controls.Add(this.gyorsRb);
            this.beallitasokTpg.Controls.Add(this.kozepesRb);
            this.beallitasokTpg.Controls.Add(this.lassuRb);
            this.beallitasokTpg.Controls.Add(this.linkHozzaadBtn);
            this.beallitasokTpg.Controls.Add(this.linkHozzaadTxt);
            this.beallitasokTpg.Controls.Add(this.label6);
            this.beallitasokTpg.Controls.Add(this.label5);
            this.beallitasokTpg.Controls.Add(this.automatikusVetitesCB);
            this.beallitasokTpg.Location = new System.Drawing.Point(4, 22);
            this.beallitasokTpg.Name = "beallitasokTpg";
            this.beallitasokTpg.Padding = new System.Windows.Forms.Padding(3);
            this.beallitasokTpg.Size = new System.Drawing.Size(754, 368);
            this.beallitasokTpg.TabIndex = 1;
            this.beallitasokTpg.Text = "Beállítások";
            this.beallitasokTpg.UseVisualStyleBackColor = true;
            // 
            // sebessegTxt
            // 
            this.sebessegTxt.AutoSize = true;
            this.sebessegTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.sebessegTxt.Location = new System.Drawing.Point(495, 46);
            this.sebessegTxt.Name = "sebessegTxt";
            this.sebessegTxt.Size = new System.Drawing.Size(95, 24);
            this.sebessegTxt.TabIndex = 12;
            this.sebessegTxt.Text = "Sebesség";
            // 
            // gyorsRb
            // 
            this.gyorsRb.AutoSize = true;
            this.gyorsRb.Location = new System.Drawing.Point(500, 138);
            this.gyorsRb.Name = "gyorsRb";
            this.gyorsRb.Size = new System.Drawing.Size(52, 17);
            this.gyorsRb.TabIndex = 11;
            this.gyorsRb.TabStop = true;
            this.gyorsRb.Text = "Gyors";
            this.gyorsRb.UseVisualStyleBackColor = true;
            // 
            // kozepesRb
            // 
            this.kozepesRb.AutoSize = true;
            this.kozepesRb.Location = new System.Drawing.Point(499, 115);
            this.kozepesRb.Name = "kozepesRb";
            this.kozepesRb.Size = new System.Drawing.Size(66, 17);
            this.kozepesRb.TabIndex = 10;
            this.kozepesRb.TabStop = true;
            this.kozepesRb.Text = "Közepes";
            this.kozepesRb.UseVisualStyleBackColor = true;
            // 
            // lassuRb
            // 
            this.lassuRb.AutoSize = true;
            this.lassuRb.Checked = true;
            this.lassuRb.Location = new System.Drawing.Point(499, 92);
            this.lassuRb.Name = "lassuRb";
            this.lassuRb.Size = new System.Drawing.Size(53, 17);
            this.lassuRb.TabIndex = 9;
            this.lassuRb.TabStop = true;
            this.lassuRb.Text = "Lassú";
            this.lassuRb.UseVisualStyleBackColor = true;
            // 
            // linkHozzaadBtn
            // 
            this.linkHozzaadBtn.Location = new System.Drawing.Point(318, 314);
            this.linkHozzaadBtn.Name = "linkHozzaadBtn";
            this.linkHozzaadBtn.Size = new System.Drawing.Size(75, 23);
            this.linkHozzaadBtn.TabIndex = 8;
            this.linkHozzaadBtn.Text = "Hozzáadás";
            this.linkHozzaadBtn.UseVisualStyleBackColor = true;
            this.linkHozzaadBtn.Click += new System.EventHandler(this.linkHozzaadBtn_Click);
            // 
            // linkHozzaadTxt
            // 
            this.linkHozzaadTxt.Location = new System.Drawing.Point(178, 270);
            this.linkHozzaadTxt.Name = "linkHozzaadTxt";
            this.linkHozzaadTxt.Size = new System.Drawing.Size(369, 20);
            this.linkHozzaadTxt.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.label6.Location = new System.Drawing.Point(286, 234);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(161, 22);
            this.label6.TabIndex = 6;
            this.label6.Text = "Új kép hozzáadása";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label5.Location = new System.Drawing.Point(284, 27);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(146, 31);
            this.label5.TabIndex = 5;
            this.label5.Text = "Beállítások";
            // 
            // automatikusVetitesCB
            // 
            this.automatikusVetitesCB.AutoSize = true;
            this.automatikusVetitesCB.Location = new System.Drawing.Point(309, 134);
            this.automatikusVetitesCB.Name = "automatikusVetitesCB";
            this.automatikusVetitesCB.Size = new System.Drawing.Size(84, 17);
            this.automatikusVetitesCB.TabIndex = 4;
            this.automatikusVetitesCB.Text = "Autómatikus";
            this.automatikusVetitesCB.UseVisualStyleBackColor = true;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 10;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Enabled = true;
            this.timer2.Interval = 3000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // felismeroTpg
            // 
            this.felismeroTpg.Controls.Add(this.label13);
            this.felismeroTpg.Controls.Add(this.pontLbl);
            this.felismeroTpg.Controls.Add(this.label11);
            this.felismeroTpg.Controls.Add(this.pontBolLbl);
            this.felismeroTpg.Controls.Add(this.ellenorizBtn);
            this.felismeroTpg.Controls.Add(this.varosCB);
            this.felismeroTpg.Controls.Add(this.label9);
            this.felismeroTpg.Controls.Add(this.orszagLbl);
            this.felismeroTpg.Controls.Add(this.label);
            this.felismeroTpg.Controls.Add(this.label8);
            this.felismeroTpg.Location = new System.Drawing.Point(4, 22);
            this.felismeroTpg.Name = "felismeroTpg";
            this.felismeroTpg.Size = new System.Drawing.Size(768, 400);
            this.felismeroTpg.TabIndex = 5;
            this.felismeroTpg.Text = "Felismerő";
            this.felismeroTpg.UseVisualStyleBackColor = true;
            this.felismeroTpg.Click += new System.EventHandler(this.felismeroTpg_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label8.Location = new System.Drawing.Point(228, 23);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(315, 31);
            this.label8.TabIndex = 0;
            this.label8.Text = "Ország város felismerő";
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.label.Location = new System.Drawing.Point(241, 125);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(82, 25);
            this.label.TabIndex = 2;
            this.label.Text = "Ország:";
            // 
            // orszagLbl
            // 
            this.orszagLbl.AutoSize = true;
            this.orszagLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.orszagLbl.Location = new System.Drawing.Point(405, 126);
            this.orszagLbl.Name = "orszagLbl";
            this.orszagLbl.Size = new System.Drawing.Size(60, 24);
            this.orszagLbl.TabIndex = 3;
            this.orszagLbl.Text = "label9";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.label9.Location = new System.Drawing.Point(241, 252);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(70, 25);
            this.label9.TabIndex = 4;
            this.label9.Text = "Város:";
            // 
            // varosCB
            // 
            this.varosCB.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.varosCB.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.varosCB.FormattingEnabled = true;
            this.varosCB.Location = new System.Drawing.Point(374, 256);
            this.varosCB.Name = "varosCB";
            this.varosCB.Size = new System.Drawing.Size(121, 21);
            this.varosCB.TabIndex = 5;
            // 
            // ellenorizBtn
            // 
            this.ellenorizBtn.Location = new System.Drawing.Point(362, 323);
            this.ellenorizBtn.Name = "ellenorizBtn";
            this.ellenorizBtn.Size = new System.Drawing.Size(75, 23);
            this.ellenorizBtn.TabIndex = 6;
            this.ellenorizBtn.Text = "Ellenőrzés";
            this.ellenorizBtn.UseVisualStyleBackColor = true;
            this.ellenorizBtn.Click += new System.EventHandler(this.ellenorizBtn_Click);
            // 
            // pontBolLbl
            // 
            this.pontBolLbl.AutoSize = true;
            this.pontBolLbl.Location = new System.Drawing.Point(52, 357);
            this.pontBolLbl.Name = "pontBolLbl";
            this.pontBolLbl.Size = new System.Drawing.Size(13, 13);
            this.pontBolLbl.TabIndex = 7;
            this.pontBolLbl.Text = "0";
            this.pontBolLbl.Click += new System.EventHandler(this.pontBolLbl_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(122, 357);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(29, 13);
            this.label11.TabIndex = 8;
            this.label11.Text = "Pont";
            // 
            // pontLbl
            // 
            this.pontLbl.AutoSize = true;
            this.pontLbl.Location = new System.Drawing.Point(89, 357);
            this.pontLbl.Name = "pontLbl";
            this.pontLbl.Size = new System.Drawing.Size(13, 13);
            this.pontLbl.TabIndex = 9;
            this.pontLbl.Text = "0";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(71, 357);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(12, 13);
            this.label13.TabIndex = 10;
            this.label13.Text = "/";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.kepTPg.ResumeLayout(false);
            this.kepTPg.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kepPb)).EndInit();
            this.kepMozgasTPg.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.mozgoPb)).EndInit();
            this.sudokuTPg.ResumeLayout(false);
            this.sudokuTPg.PerformLayout();
            this.listTPg.ResumeLayout(false);
            this.listTPg.PerformLayout();
            this.DiavetitesTpg.ResumeLayout(false);
            this.DiavetitesTpg.PerformLayout();
            this.tabControl2.ResumeLayout(false);
            this.megjelenitesTpg.ResumeLayout(false);
            this.megjelenitesTpg.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kepekPb)).EndInit();
            this.beallitasokTpg.ResumeLayout(false);
            this.beallitasokTpg.PerformLayout();
            this.felismeroTpg.ResumeLayout(false);
            this.felismeroTpg.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage kepTPg;
        private System.Windows.Forms.HScrollBar magassagVSb;
        private System.Windows.Forms.PictureBox kepPb;
        private System.Windows.Forms.HScrollBar szelessegHSb;
        private System.Windows.Forms.TabPage kepMozgasTPg;
        private System.Windows.Forms.Button mutasdBTn;
        private System.Windows.Forms.TextBox utvonalTxt;
        private System.Windows.Forms.PictureBox mozgoPb;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TabPage sudokuTPg;
        private System.Windows.Forms.Button hozzaadBTn;
        private System.Windows.Forms.Button kivonBTn;
        private System.Windows.Forms.TextBox meretTxt;
        private System.Windows.Forms.TextBox kezdoallapotTxt;
        private System.Windows.Forms.Label hosszTxt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button ellenorzesBTn;
        private System.Windows.Forms.TabPage listTPg;
        private System.Windows.Forms.ListBox listaLB;
        private System.Windows.Forms.Button ujElemBtn;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox termekTxt;
        private System.Windows.Forms.Button listaTorolBtn;
        private System.Windows.Forms.Button termekTorolBtn;
        private System.Windows.Forms.ComboBox bevasarloListaCB;
        private System.Windows.Forms.Button ComboHozzaAdBtn;
        private System.Windows.Forms.TextBox comboBevasarloTxt;
        private System.Windows.Forms.TabPage DiavetitesTpg;
        private System.Windows.Forms.PictureBox kepekPb;
        private System.Windows.Forms.Button jobbraNyilBtn;
        private System.Windows.Forms.Button balraNyilBtn;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage megjelenitesTpg;
        private System.Windows.Forms.TabPage beallitasokTpg;
        private System.Windows.Forms.Button linkHozzaadBtn;
        private System.Windows.Forms.TextBox linkHozzaadTxt;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckBox automatikusVetitesCB;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label sorszamTxt;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Label sebessegTxt;
        private System.Windows.Forms.RadioButton gyorsRb;
        private System.Windows.Forms.RadioButton kozepesRb;
        private System.Windows.Forms.RadioButton lassuRb;
        private System.Windows.Forms.TabPage felismeroTpg;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox varosCB;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label orszagLbl;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Button ellenorizBtn;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label pontLbl;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label pontBolLbl;
    }
}

