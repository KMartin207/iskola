﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Vezerlok
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void colorPanel_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            redUpDownBox.Value = redscroll.Value;
            greenUpDownBox.Value = greenScroll.Value;
            blueUpDownBox.Value = blueScroll.Value;
            colorPanel.BackColor = Color.FromArgb(redscroll.Value, greenScroll.Value, blueScroll.Value);
        }

        private void redUpDownBox_ValueChanged(object sender, EventArgs e)
        {
            redscroll.Value = (int)redUpDownBox.Value;
        }

        private void greenUpDownBox_ValueChanged(object sender, EventArgs e)
        {
            greenScroll.Value = (int)greenUpDownBox.Value;
        }

        private void blueUpDownBox_ValueChanged(object sender, EventArgs e)
        {
            blueScroll.Value = (int)blueUpDownBox.Value;
        }

        Random rnd = new Random();

        private void kapjEl_Click(object sender, EventArgs e)
        {

            int gombX = rnd.Next(0, vezerloBox.Width);
            int gombY = rnd.Next(0, vezerloBox.Height);

            kapjEl.Location = new Point(gombX, gombY);


        }
    }
}
