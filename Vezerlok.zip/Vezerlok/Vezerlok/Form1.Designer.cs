﻿namespace Vezerlok
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.vezerloBox = new System.Windows.Forms.GroupBox();
            this.blueScroll = new System.Windows.Forms.HScrollBar();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.greenScroll = new System.Windows.Forms.HScrollBar();
            this.redscroll = new System.Windows.Forms.HScrollBar();
            this.colorPanel = new System.Windows.Forms.Panel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.redUpDownBox = new System.Windows.Forms.NumericUpDown();
            this.greenUpDownBox = new System.Windows.Forms.NumericUpDown();
            this.blueUpDownBox = new System.Windows.Forms.NumericUpDown();
            this.kapjEl = new System.Windows.Forms.Button();
            this.vezerloBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.redUpDownBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.greenUpDownBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blueUpDownBox)).BeginInit();
            this.SuspendLayout();
            // 
            // vezerloBox
            // 
            this.vezerloBox.Controls.Add(this.kapjEl);
            this.vezerloBox.Controls.Add(this.blueUpDownBox);
            this.vezerloBox.Controls.Add(this.greenUpDownBox);
            this.vezerloBox.Controls.Add(this.redUpDownBox);
            this.vezerloBox.Controls.Add(this.colorPanel);
            this.vezerloBox.Controls.Add(this.redscroll);
            this.vezerloBox.Controls.Add(this.greenScroll);
            this.vezerloBox.Controls.Add(this.label3);
            this.vezerloBox.Controls.Add(this.label2);
            this.vezerloBox.Controls.Add(this.label1);
            this.vezerloBox.Controls.Add(this.blueScroll);
            this.vezerloBox.Location = new System.Drawing.Point(12, 12);
            this.vezerloBox.Name = "vezerloBox";
            this.vezerloBox.Size = new System.Drawing.Size(776, 426);
            this.vezerloBox.TabIndex = 0;
            this.vezerloBox.TabStop = false;
            this.vezerloBox.Text = "Vezérlők";
            // 
            // blueScroll
            // 
            this.blueScroll.Location = new System.Drawing.Point(192, 234);
            this.blueScroll.Maximum = 255;
            this.blueScroll.Name = "blueScroll";
            this.blueScroll.Size = new System.Drawing.Size(220, 21);
            this.blueScroll.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(78, 146);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Red";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Green;
            this.label2.Location = new System.Drawing.Point(78, 189);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Green";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label3.Location = new System.Drawing.Point(78, 234);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(28, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Blue";
            // 
            // greenScroll
            // 
            this.greenScroll.Location = new System.Drawing.Point(192, 189);
            this.greenScroll.Maximum = 255;
            this.greenScroll.Name = "greenScroll";
            this.greenScroll.Size = new System.Drawing.Size(220, 21);
            this.greenScroll.TabIndex = 6;
            // 
            // redscroll
            // 
            this.redscroll.Location = new System.Drawing.Point(193, 146);
            this.redscroll.Maximum = 255;
            this.redscroll.Name = "redscroll";
            this.redscroll.Size = new System.Drawing.Size(220, 21);
            this.redscroll.TabIndex = 7;
            // 
            // colorPanel
            // 
            this.colorPanel.Location = new System.Drawing.Point(545, 107);
            this.colorPanel.Name = "colorPanel";
            this.colorPanel.Size = new System.Drawing.Size(200, 200);
            this.colorPanel.TabIndex = 8;
            this.colorPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.colorPanel_Paint);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // redUpDownBox
            // 
            this.redUpDownBox.Location = new System.Drawing.Point(459, 148);
            this.redUpDownBox.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.redUpDownBox.Name = "redUpDownBox";
            this.redUpDownBox.Size = new System.Drawing.Size(70, 20);
            this.redUpDownBox.TabIndex = 10;
            this.redUpDownBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.redUpDownBox.ValueChanged += new System.EventHandler(this.redUpDownBox_ValueChanged);
            // 
            // greenUpDownBox
            // 
            this.greenUpDownBox.Location = new System.Drawing.Point(459, 189);
            this.greenUpDownBox.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.greenUpDownBox.Name = "greenUpDownBox";
            this.greenUpDownBox.Size = new System.Drawing.Size(70, 20);
            this.greenUpDownBox.TabIndex = 11;
            this.greenUpDownBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.greenUpDownBox.ValueChanged += new System.EventHandler(this.greenUpDownBox_ValueChanged);
            // 
            // blueUpDownBox
            // 
            this.blueUpDownBox.Location = new System.Drawing.Point(459, 234);
            this.blueUpDownBox.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.blueUpDownBox.Name = "blueUpDownBox";
            this.blueUpDownBox.Size = new System.Drawing.Size(70, 20);
            this.blueUpDownBox.TabIndex = 12;
            this.blueUpDownBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.blueUpDownBox.ValueChanged += new System.EventHandler(this.blueUpDownBox_ValueChanged);
            // 
            // kapjEl
            // 
            this.kapjEl.Location = new System.Drawing.Point(16, 41);
            this.kapjEl.Name = "kapjEl";
            this.kapjEl.Size = new System.Drawing.Size(75, 23);
            this.kapjEl.TabIndex = 13;
            this.kapjEl.Text = "Kapj el!";
            this.kapjEl.UseVisualStyleBackColor = true;
            this.kapjEl.Click += new System.EventHandler(this.kapjEl_Click);
            this.kapjEl.MouseEnter += new System.EventHandler(this.kapjEl_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.vezerloBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.vezerloBox.ResumeLayout(false);
            this.vezerloBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.redUpDownBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.greenUpDownBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blueUpDownBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox vezerloBox;
        private System.Windows.Forms.Panel colorPanel;
        private System.Windows.Forms.HScrollBar redscroll;
        private System.Windows.Forms.HScrollBar greenScroll;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.HScrollBar blueScroll;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.NumericUpDown blueUpDownBox;
        private System.Windows.Forms.NumericUpDown greenUpDownBox;
        private System.Windows.Forms.NumericUpDown redUpDownBox;
        private System.Windows.Forms.Button kapjEl;
    }
}

