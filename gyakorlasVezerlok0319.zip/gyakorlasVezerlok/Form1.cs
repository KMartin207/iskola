﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using static System.Net.WebRequestMethods;

namespace gyakorlasVezerlok
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void mutasdBTn_Click(object sender, EventArgs e)
        {
            kepPb.ImageLocation = utvonalTxt.Text;
        }

        private void magassagVSb_Scroll(object sender, ScrollEventArgs e)
        {
            kepPb.Height = magassagVSb.Value;
        }

        private void szelessegHSb_Scroll(object sender, ScrollEventArgs e)
        {
            kepPb.Width = szelessegHSb.Value;
        }

        private void utvonalTxt_TextChanged(object sender, EventArgs e)
        {

        }

        int vx = 10; 
        int vy = -10;

        int ujx;
        int ujy;

        static Random rnd = new Random();

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (mozgoPb.Left <= 0 )
            {
                vx = 30;
                kepMozgasTPg.BackColor = Color.FromArgb(rnd.Next(0, 255));
            }
            if (mozgoPb.Left + mozgoPb.Width >= kepMozgasTPg.Width )
            {
                vx = -30;
                kepMozgasTPg.BackColor = Color.Red;
            }
            if (mozgoPb.Top <= 0)
            {
                vy = 30;
                kepMozgasTPg.BackColor = Color.Blue;
            }
            if (mozgoPb.Top + mozgoPb.Height >= kepMozgasTPg.Height)
            {
                vy = -30;
                kepMozgasTPg.BackColor = Color.Gray;
            }



            ujx = mozgoPb.Left + vx;
            ujy = mozgoPb.Top + vy;

            this.Text = Convert.ToString(ujx) + " " + Convert.ToString(ujy);

            mozgoPb.Location = new Point(ujx, ujy);

        }

        private void kivonBTn_Click(object sender, EventArgs e)
        {
            int meret = Convert.ToInt32(meretTxt.Text);
            if (Convert.ToInt32(meretTxt.Text) > 4)
            {
                meret--;
                meretTxt.Text = Convert.ToString(meret);
            }
        }

        private void hozzaadBTn_Click(object sender, EventArgs e)
        {
            int meret = Convert.ToInt32(meretTxt.Text);
            if ( Convert.ToInt32(meretTxt.Text) < 9)
            {
                meret++;
                meretTxt.Text = Convert.ToString(meret);
            }
        }

        private void meretTxt_TextChanged(object sender, EventArgs e)
        {
            if (Convert.ToInt32(meretTxt.Text) < 4 )
            {
                meretTxt.Text = "4";
            }

            if (Convert.ToInt32(meretTxt.Text) > 9)
            {
                meretTxt.Text = "9";
            }
        }

        private void kezdoallapotTxt_TextChanged(object sender, EventArgs e)
        {
            hosszTxt.Text = Convert.ToString(kezdoallapotTxt.Text.Length);
        }

        private void ellenorzesBTn_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(kezdoallapotTxt.Text.Length) == Convert.ToInt32(meretTxt.Text) * Convert.ToInt32(meretTxt.Text))
            {
                MessageBox.Show("A feladvány megfelelő hosszúságú!", "Ellenőrzés", MessageBoxButtons.OK, MessageBoxIcon.None);
            }
            else if(Convert.ToInt32(kezdoallapotTxt.Text.Length) < Convert.ToInt32(meretTxt.Text) * Convert.ToInt32(meretTxt.Text))
            {
                MessageBox.Show($"A feladvány rövid: kell még {(Convert.ToInt32(meretTxt.Text) * Convert.ToInt32(meretTxt.Text)) - Convert.ToInt32(kezdoallapotTxt.Text.Length)} számjegy!", "Ellenőrzés", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (Convert.ToInt32(kezdoallapotTxt.Text.Length) > Convert.ToInt32(meretTxt.Text) * Convert.ToInt32(meretTxt.Text))
            {
                MessageBox.Show($"A feladvány hosszú: törlendő {(Convert.ToInt32(meretTxt.Text) * Convert.ToInt32(meretTxt.Text)) - Convert.ToInt32(kezdoallapotTxt.Text.Length)} számjegy!", "Ellenőrzés", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        static List<string> linkek = new List<string>();
        static string sor;

        private void Form1_Load(object sender, EventArgs e)
        {
            //ControlBox = false;


            StreamReader olvasocsatorna = new StreamReader(@"E:\12\gyakorlasVezerlok\linkek.txt", true);

            while (!olvasocsatorna.EndOfStream)
            {
                sor = olvasocsatorna.ReadLine();

                linkek.Add(sor);

            }
            olvasocsatorna.Close();

        }

        private void ujElemBtn_Click(object sender, EventArgs e)
        {
            listaLB.Items.Add("-" + termekTxt.Text);
            termekTxt.Text = "";
        }

        private void listaTorolBtn_Click(object sender, EventArgs e)
        {
            listaLB.Items.Clear();
        }

        private void termekTorolBtn_Click(object sender, EventArgs e)
        {
            listaLB.Items.Remove(listaLB.SelectedItem);
        }

        private void termekTxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void ComboHozzaAdBtn_Click(object sender, EventArgs e)
        {
            bevasarloListaCB.Items.Add(comboBevasarloTxt.Text);
            comboBevasarloTxt.Text = "";
        }

        private void kepekPb_Click(object sender, EventArgs e)
        {

        }

        static int kepSorSzam = 1;

        private void jobbraNyilBtn_Click(object sender, EventArgs e)
        {
            if (kepSorSzam < linkek.Count-1)
            {
                kepSorSzam++;
            }
            else
            {
                kepSorSzam = 0;
            }

            kepekPb.ImageLocation = linkek[kepSorSzam];
            sorszamTxt.Text = Convert.ToString(kepSorSzam);
        }


        private void balraNyilBtn_Click(object sender, EventArgs e)
        {
            if (kepSorSzam > 0)
            {
                kepSorSzam--;
            }
            else
            {
                kepSorSzam = linkek.Count - 1;
            }

            kepekPb.ImageLocation = linkek[kepSorSzam];
            sorszamTxt.Text = Convert.ToString(kepSorSzam);
        }

        private void sorszamTxt_Click(object sender, EventArgs e)
        {

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (automatikusVetitesCB.Checked)
            {
                balraNyilBtn.Enabled = false;
                jobbraNyilBtn.Enabled = false;

                if (lassuRb.Checked)
                {
                    timer2.Interval = 3000;
                }
                if (kozepesRb.Checked)
                {
                    timer2.Interval = 1500;
                }
                if (gyorsRb.Checked)
                {
                    timer2.Interval = 750;
                }


                kepSorSzam++;

                kepekPb.ImageLocation = linkek[kepSorSzam];

                if (kepSorSzam == linkek.Count - 1)
                {
                    kepSorSzam = 0;
                }

            }
            else
            {
                balraNyilBtn.Enabled = true;
                jobbraNyilBtn.Enabled = true;
            }
        }

        private void linkHozzaadBtn_Click(object sender, EventArgs e)
        {



            StreamWriter irocsatorna = new StreamWriter(@"E:\12\gyakorlasVezerlok\linkek.txt", true);

            irocsatorna.WriteLine(linkHozzaadTxt.Text);
            linkHozzaadTxt.Text = "";

            irocsatorna.Close();

            linkek.Clear();
            StreamReader olvasocsatorna = new StreamReader(@"E:\12\gyakorlasVezerlok\linkek.txt", true);

            while (!olvasocsatorna.EndOfStream)
            {
                sor = olvasocsatorna.ReadLine();

                
                linkek.Add(sor);

            }
            olvasocsatorna.Close();
        }
    }
}
